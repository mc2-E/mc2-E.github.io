Molten-salt corrosion analytical tools

Extract the entire ZIP first. Open Start_Here.html in a modern web browser.
Keep the folder structure unchanged so report/evidence links continue to work.
The HTML files contain the calculation source; there is no simulation launcher.
External literature links require internet access.

Rates are Cr-equivalent removal, not wall recession. Bulk coefficients are frozen
at a chosen reference; see each explorer for its particular surface law and assumptions.
