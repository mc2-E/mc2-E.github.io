NUEN265 — Crystal Structures of Solids, Part II: Compounds and Alloys

Extract this ZIP, then open Compounds_and_Alloys_Explorer.html in a modern browser.
The seven tabs, illustrations and calculations work offline. Reference links need
internet access. No sign-in or installation is needed for the online explorer.

Online explorer: https://mc2-e.github.io/teaching/nuen265/compounds-and-alloys/
Course resources: https://mc2-e.github.io/teaching/nuen265/

Start with Sizes & structures, then work through interstitial sites, AB structures,
nuclear oxides, complex structures, alloy order and density. Each tab includes
questions, hints and explanations. Crystal models and density calculations are
teaching examples; source conventions and limitations are stated in the explorer.
