NUEN265 — Introduction to Materials Science for Nuclear Energy Applications
Crystal structures of elemental solids

Extract this ZIP and open Crystal_Structures_Explorer.html in a modern web browser.
The explorer works offline. Optional reference links require internet access.

Topics: lattices, symmetry, stacking, unit cells, coordination and packing,
cell volume, density, and nuclear metals (U, Pu, Th).
